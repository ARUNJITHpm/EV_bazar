# Chargeworthy — site and assessment flow

React + Vite. Marketing page and the seven-step assessment flow, on the
published Chargeworthy Mapbox style.

## Run

```bash
npm install
cp .env.example .env.local     # add your Mapbox public token
npm run dev
```

`npm run build` → `dist/`. Verified building clean.

## Layout

```
src/
  styles.css            all design tokens; retuning the palette is one file
  lib/mapCore.js        Mapbox config, palette, geometry, geocoding
  lib/useReveal.js      IntersectionObserver reveals, count-up, scroll progress
  components/Maps.jsx   HeroMap · LocateMap · BackgroundMap (lazy-loaded)
  pages/Landing.jsx     six marketing sections
  pages/Flow.jsx        the assessment flow
  App.jsx               hash routing — browser back works for free
```

## What was verified, not assumed

Built and rendered in a headless browser at 390 / 768 / 1440px:

- Zero horizontal overflow at all three widths
- No JavaScript errors on the landing page or in the flow
- 34 factor chips render; proof row reads "38% advised against"
- Flow: one question per screen, two large answers, back control present
- Every interactive element ≥44px tall except the Mapbox logo link inside
  the map canvas, which is third-party and sits in a `pointer-events: none`
  container

**Not verified:** anything requiring a live Mapbox connection. The build
sandbox had no network route to `api.mapbox.com`, so map tiles, geocoding
responses and the pin never rendered here. See "Check on first run".

## Performance

Mapbox is loaded lazily via dynamic import and only once the map container is
within 400px of the viewport.

| | gzipped |
|---|---|
| Initial (HTML + app + CSS) | ~58 KB |
| Mapbox chunk, on demand | ~521 KB |

The page paints, reads and scrolls before Mapbox arrives.

## Motion

Entrances 520ms, state changes 200ms, `cubic-bezier(0.16, 1, 0.3, 1)`, rise
20px, 40–60ms stagger, fire once at 20% viewport entry, never replay.
Full `prefers-reduced-motion` support: entrances become instant, counters
render final values, the scroll-scrub becomes static.

Two deliberate departures from the brief:

- **No scroll-pinning on "How it works."** A scroll-jack is the one motion
  effect most likely to feel broken on a mid-range Android, and on a page
  selling restraint it is the wrong signal. The three steps reveal on a
  stagger instead.
- **The report showcase keeps its scroll-scrub**, because there the movement
  mirrors reading down a document.

## Check on first run

1. **Geocoding response shape.** `normalizeFeature()` in `lib/mapCore.js` is
   the only place the payload is read; it handles both v6 and v5 shapes and
   logs the first raw response to the console. If a field lands wrong, fix it
   there and nowhere else.

2. **`roadClass` is always null.** Mapbox geocoding does not return road
   classification. The confirmation card shows "Not yet determined" rather
   than a guess. Wire it to OSM highway tags or your own roads dataset.

3. **The working screen is a stub.** `runAssessmentStub` in `pages/Flow.jsx`
   fakes progress with timers. Replace it with your real backend call, which
   should report each source as it genuinely resolves. If the real work takes
   two seconds, show two seconds — a padded progress bar is the one element
   here that would undo everything else this site argues.

4. **Mapbox attribution.** The dimmed background map has its attribution
   control disabled (unreadable at 30% opacity), so attribution is rendered as
   real text in the flow chrome. Confirm this satisfies your Mapbox plan's
   attribution terms — the logo requirement is separate from data attribution.

5. **Restrict the token** to your domain before deploying.

## Still placeholder

- Prediction accuracy renders as `[XX%]` — no figure was ever supplied.
- Partner names are set as type, not logos. Nothing goes up without written
  permission from GOEC, ChargeMOD, ChargeZone, Lubi, ABB and Quench.
- Result figures (₹34L / 2.1% / 7.1%) are illustrative sample values.
- `og:image` points at `/og-identity.png` — export it from the social canvas
  and drop it in `public/`.
