// Map components. Mapbox GL JS is loaded lazily — it is the heaviest
// dependency on the page and must not block first paint on a 4G phone.

import { useEffect, useRef, useState, useCallback } from 'react';

/** Loads the map module only once the container is near the viewport. */
function useLazyMapModule(containerRef) {
  const [mod, setMod] = useState(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || mod) return undefined;

    let alive = true;
    const load = () => {
      import('../lib/mapCore').then((m) => {
        if (alive) setMod(m);
      });
    };

    if (!('IntersectionObserver' in window)) {
      load();
      return () => { alive = false; };
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        observer.disconnect();
        load();
      },
      { rootMargin: '400px' },
    );
    observer.observe(el);

    return () => {
      alive = false;
      observer.disconnect();
    };
  }, [containerRef, mod]);

  return mod;
}

function useMap(containerRef, mod, options, onReady) {
  const mapRef = useRef(null);
  const readyRef = useRef(onReady);
  readyRef.current = onReady;

  useEffect(() => {
    if (!mod || !containerRef.current || mapRef.current) return undefined;

    // A missing or rejected token must not take the page down with it. The map
    // panel stays empty and everything else on the page keeps working.
    let map;
    try {
      map = new mod.mapboxgl.Map({
        container: containerRef.current,
        style: mod.MAP_STYLE,
        center: mod.DEFAULT_CENTER,
        zoom: mod.DEFAULT_ZOOM,
        ...options,
      });
    } catch (err) {
      console.error('[Chargeworthy] map could not start:', err);
      return undefined;
    }

    mapRef.current = map;
    map.on('error', (e) => console.error('[Chargeworthy] map error:', e?.error ?? e));
    map.on('load', () => readyRef.current?.(map, mod));

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // Options are read once at construction, deliberately.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mod]);

  return mapRef;
}

// --- Hero --------------------------------------------------------------

export function HeroMap({ radiiKm = [3, 5, 10], competitors = [], style }) {
  const ref = useRef(null);
  const mod = useLazyMapModule(ref);

  useMap(
    ref,
    mod,
    { zoom: 12.4, interactive: false },
    useCallback((map, m) => {
      m.setRings(map, m.DEFAULT_CENTER, radiiKm);
      m.setCompetitors(map, competitors);
      new m.mapboxgl.Marker({ element: m.createPinElement(), anchor: 'bottom' })
        .setLngLat(m.DEFAULT_CENTER)
        .addTo(map);
    }, [radiiKm, competitors]),
  );

  return (
    <div
      ref={ref}
      aria-hidden="true"
      style={{ background: 'var(--surface)', border: '1px solid var(--line)', ...style }}
    />
  );
}

// --- Dimmed background, continuous behind every flow step ---------------

export function BackgroundMap({ center, opacity = 0.3 }) {
  const ref = useRef(null);
  const mod = useLazyMapModule(ref);
  const markerRef = useRef(null);

  const mapRef = useMap(
    ref,
    mod,
    { zoom: 13, interactive: false, attributionControl: false },
    useCallback((map, m) => {
      markerRef.current = new m.mapboxgl.Marker({
        element: m.createPinElement(),
        anchor: 'bottom',
      })
        .setLngLat(center ?? m.DEFAULT_CENTER)
        .addTo(map);
    }, [center]),
  );

  // Follow the confirmed site without remounting the map.
  useEffect(() => {
    if (!center || !mapRef.current) return;
    markerRef.current?.setLngLat(center);
    mapRef.current.easeTo({ center, duration: 700 });
  }, [center, mapRef]);

  return (
    <div
      ref={ref}
      aria-hidden="true"
      style={{
        position: 'absolute',
        inset: 0,
        opacity,
        pointerEvents: 'none',
        background: 'var(--ground)',
      }}
    />
  );
}

// --- Step 1: locate ----------------------------------------------------

const PIN_ICON = (
  <svg width="19" height="19" viewBox="0 0 20 20" fill="none" stroke="currentColor"
       strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M10 18s6-5.2 6-9.4A6 6 0 0 0 4 8.6C4 12.8 10 18 10 18z" />
    <circle cx="10" cy="8.6" r="2.1" />
  </svg>
);

export function LocateMap({ onConfirm }) {
  const ref = useRef(null);
  const mod = useLazyMapModule(ref);
  const markerRef = useRef(null);
  const abortRef = useRef(null);

  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [site, setSite] = useState(null);
  const [busy, setBusy] = useState(false);

  const place = useCallback(async (lngLat) => {
    if (!mod) return;
    setBusy(true);
    setResults([]);
    markerRef.current?.setLngLat(lngLat);
    const resolved = await mod.reverseGeocode(lngLat);
    setSite(
      resolved ?? {
        label: 'No address found for this point',
        coordinates: lngLat,
        district: null,
        roadClass: null,
      },
    );
    setBusy(false);
  }, [mod]);

  const mapRef = useMap(
    ref,
    mod,
    {},
    useCallback((map, m) => {
      const marker = new m.mapboxgl.Marker({
        element: m.createPinElement({ draggable: true }),
        draggable: true,
        anchor: 'bottom',
      })
        .setLngLat(m.DEFAULT_CENTER)
        .addTo(map);
      markerRef.current = marker;
      marker.on('dragend', () => {
        const { lng, lat } = marker.getLngLat();
        place([lng, lat]);
      });
      map.on('click', (e) => place([e.lngLat.lng, e.lngLat.lat]));
    }, [place]),
  );

  useEffect(() => {
    if (!mod || query.trim().length < 3) {
      setResults([]);
      return undefined;
    }
    const timer = setTimeout(async () => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;
      setResults(await mod.forwardGeocode(query, { signal: controller.signal }));
    }, 280);
    return () => clearTimeout(timer);
  }, [query, mod]);

  const choose = (r) => {
    if (!r.coordinates) return;
    setQuery(r.label);
    setResults([]);
    setSite(r);
    markerRef.current?.setLngLat(r.coordinates);
    mapRef.current?.flyTo({ center: r.coordinates, zoom: 15, duration: 900 });
  };

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div ref={ref} style={{ position: 'absolute', inset: 0, background: 'var(--surface)' }} />

      <div style={{
        position: 'absolute', top: 32, left: '50%', transform: 'translateX(-50%)',
        width: 'min(620px, calc(100% - 40px))', zIndex: 2,
      }}>
        <div className="field" style={{ color: 'var(--muted)' }}>
          {PIN_ICON}
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Drop a pin, or type the location"
            aria-label="Search for the site location"
            autoComplete="off"
          />
        </div>

        {/* A list of large rows, never a compact dropdown. */}
        {results.length > 0 && (
          <ul style={{
            listStyle: 'none', margin: 0, padding: 0,
            background: 'var(--surface)', border: '1px solid var(--line)', borderTop: 'none',
            maxHeight: '46vh', overflowY: 'auto',
          }}>
            {results.map((r) => (
              <li key={r.id ?? r.label}>
                <button
                  type="button"
                  onClick={() => choose(r)}
                  className="answer"
                  style={{ width: '100%', minHeight: 64, padding: '14px 20px', gap: 4, border: 'none', borderBottom: '1px solid var(--line)' }}
                >
                  <span style={{ fontSize: 17 }}>{r.label}</span>
                  {r.district && <span className="muted" style={{ fontSize: 15 }}>{r.district}</span>}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {site && (
        <div style={{
          position: 'absolute', bottom: 32, left: '50%', transform: 'translateX(-50%)',
          width: 'min(720px, calc(100% - 40px))', zIndex: 2,
          background: 'var(--surface)', border: '1px solid var(--line)',
          padding: 'clamp(24px, 4vw, 36px) clamp(20px, 4vw, 40px)',
          display: 'flex', flexDirection: 'column', gap: 24,
          maxHeight: '62vh', overflowY: 'auto',
        }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className="mono muted" style={{ fontSize: 13, letterSpacing: '0.14em', textTransform: 'uppercase' }}>
              {busy ? 'Locating…' : 'Is this the spot?'}
            </div>
            <h2 style={{ fontSize: 'clamp(21px, 3vw, 27px)' }}>{site.label}</h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 20 }}>
            <Field label="District" value={site.district ?? '—'} />
            <Field label="Road class" value={site.roadClass ?? 'Not yet determined'} />
            <Field
              label="Coordinates"
              mono
              value={site.coordinates ? `${site.coordinates[1].toFixed(4)}, ${site.coordinates[0].toFixed(4)}` : '—'}
            />
          </div>

          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            flexWrap: 'wrap', gap: 16,
            borderTop: '1px solid var(--line)', paddingTop: 22,
          }}>
            <span className="muted" style={{ display: 'inline-flex', alignItems: 'center', minHeight: 56 }}>
              Not quite? Drag the pin.
            </span>
            <button type="button" className="btn" disabled={busy} onClick={() => onConfirm(site)}>
              Yes, continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, mono = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div className="muted" style={{ fontSize: 17 }}>{label}</div>
      <div className={mono ? 'mono' : undefined} style={{ fontSize: mono ? 17 : 18 }}>{value}</div>
    </div>
  );
}
