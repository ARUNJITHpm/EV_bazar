import { useReveal, useCountUp, useScrollProgress } from '../lib/useReveal';
import { HeroMap } from '../components/Maps';

const FACTORS = [
  'Road class', 'Distance from main road', 'Carriageway direction served', 'Sub-road access',
  'Median or divider', 'Sight line', 'Turning radius', 'Entry and exit width', 'Frontage width',
  'AADT traffic count', 'Dominant flow direction', 'Peak hour timing', 'EV registrations',
  'Registration mix', 'Fleet operators within 10 km', 'Distance to nearest city', 'Tariff order',
  'Demand charges', 'Sanctioned load', 'Transformer distance', 'Transformer spare capacity',
  'Grid outage hours', 'New connection cost', 'State subsidy applicability', 'Plot area',
  'Parking bays', 'Canopy feasibility', 'Amenities within walking distance',
  'Mobile network coverage', 'Night lighting', 'Land or lease cost', 'Competitor distance',
  'Competitor density at 3 / 5 / 10 km', 'Announced stations',
];

const PIN = (
  <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor"
       strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M10 18s6-5.2 6-9.4A6 6 0 0 0 4 8.6C4 12.8 10 18 10 18z" />
    <circle cx="10" cy="8.6" r="2.1" />
  </svg>
);

function LocationCta({ id }) {
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); window.location.hash = '#/assess'; }}
      style={{ display: 'flex', gap: 12, flexWrap: 'wrap', maxWidth: 720 }}
    >
      <label htmlFor={id} style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }}>
        Site location
      </label>
      <div className="field" style={{ color: 'var(--muted)', minWidth: 260 }}>
        {PIN}
        <input id={id} placeholder="Drop a pin, or type the location" autoComplete="off" />
      </div>
      <button type="submit" className="btn">Assess this site</button>
    </form>
  );
}

function Eyebrow({ children }) {
  return (
    <div className="mono muted" style={{ fontSize: 13, letterSpacing: '0.16em', textTransform: 'uppercase' }}>
      {children}
    </div>
  );
}

function Stat({ value, suffix = '', label, decimals = 0 }) {
  const [ref, n] = useCountUp(value, { decimals });
  // Indian numbering throughout — lakh and crore, never millions.
  const shown = n.toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return (
    <div ref={ref} className="mono" style={{ fontSize: 15, letterSpacing: '0.03em', color: 'var(--muted)' }}>
      {shown}{suffix} {label}
    </div>
  );
}

// --- Sections -----------------------------------------------------------

function Header() {
  return (
    <header style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 32,
      padding: '26px var(--pad-x)', borderBottom: '1px solid var(--line)',
    }}>
      <span className="mono" style={{ fontWeight: 500, fontSize: 17, letterSpacing: '0.09em', textTransform: 'uppercase' }}>
        Chargeworthy
      </span>
      <a href="#report" style={{ display: 'inline-flex', alignItems: 'center', minHeight: 44 }}>Sample report</a>
    </header>
  );
}

function Hero() {
  const ref = useReveal(60);
  return (
    <section ref={ref}>
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 420px), 1fr))',
        gap: 'clamp(40px, 6vw, 80px)', alignItems: 'center',
        padding: 'var(--pad-y) var(--pad-x)',
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 26, maxWidth: 560 }}>
          <div data-reveal="0"><Eyebrow>Right site. Right operator.</Eyebrow></div>
          <h1 data-reveal="1" style={{ fontSize: 'clamp(34px, 5.2vw, 60px)', fontWeight: 600, letterSpacing: '-0.025em' }}>
            Will your land pay for a charger?
          </h1>
          <p data-reveal="2" className="muted" style={{ fontSize: 18 }}>
            We assess the location, set the return against what a fixed deposit would pay on the
            same money, and tell you plainly — including when the answer is no.
          </p>
          <p data-reveal="3" className="muted">
            Charging stations are built and run by operators. We are not one of them, and we
            hold no stake in any of them.
          </p>
          <div data-reveal="4"><LocationCta id="hero-location" /></div>
        </div>

        <div data-reveal="5">
          <HeroMap style={{ height: 'clamp(260px, 42vw, 452px)', width: '100%' }} />
        </div>
      </div>

      <div style={{
        display: 'flex', flexWrap: 'wrap', gap: 'clamp(16px, 4vw, 40px)',
        padding: '26px var(--pad-x) 30px', borderTop: '1px solid var(--line)',
      }}>
        <Stat value={1000} suffix="+" label="owners in our network" />
        <Stat value={340} label="sites assessed in 2025" />
        <Stat value={38} suffix="%" label="advised against" />
      </div>
    </section>
  );
}

const STEPS = [
  ['01', 'Assess the site', <>We survey the location against <span className="mono">34</span> fixed criteria and model what it would earn. If it does not clear the bar, that is where it ends.</>],
  ['02', 'Match the operator', 'A highway site and an apartment basement need different operators. We rank our partners on charger type, revenue share and how fast they reach you for a fault, then name one.'],
  ['03', 'Install and run', 'The operator supplies the charger, the installation and the management software. We stay with you through commissioning.'],
];

function HowItWorks() {
  const ref = useReveal(60);
  return (
    <section ref={ref} className="section">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(40px, 6vw, 64px)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 620 }}>
          <div data-reveal="0"><Eyebrow>How it works</Eyebrow></div>
          <h2 data-reveal="1" style={{ fontSize: 'clamp(26px, 3.4vw, 34px)' }}>Three steps, and we stop at any of them.</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 260px), 1fr))', gap: 0 }}>
          {STEPS.map(([n, title, body], i) => (
            <div
              key={n}
              data-reveal={i + 2}
              style={{
                display: 'flex', flexDirection: 'column', gap: 16,
                padding: i === 0 ? '0 clamp(24px, 4vw, 56px) 0 0' : '0 clamp(24px, 4vw, 56px)',
                borderLeft: i === 0 ? 'none' : '1px solid var(--line)',
              }}
            >
              <span className="mono" style={{ fontSize: 15, color: 'var(--slate)', letterSpacing: '0.08em' }}>{n}</span>
              <h3 style={{ fontSize: 22 }}>{title}</h3>
              <p className="muted">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function WhatWeCheck() {
  const ref = useReveal(30);
  return (
    <section ref={ref} className="section">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(36px, 5vw, 52px)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 660 }}>
          <div data-reveal="0" className="mono muted" style={{ fontSize: 14, letterSpacing: '0.05em' }}>
            34 factors, every one disclosed in your report.
          </div>
          <h2 data-reveal="1" style={{ fontSize: 'clamp(26px, 3.4vw, 34px)' }}>Nothing here is a guess.</h2>
          <p data-reveal="2" className="muted" style={{ maxWidth: 580 }}>
            Each one is measured or sourced, marked as verified or unverified, and shown with the
            direction it pushed the verdict — including the ones that argued in the site&rsquo;s favour.
          </p>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
          {FACTORS.map((f, i) => (
            <span key={f} className="chip" data-reveal={i + 3}>{f}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

function ReportPaper({ compact = false }) {
  return (
    <div style={{
      background: 'var(--paper)', color: 'var(--ink)',
      padding: compact ? '28px 30px' : 'clamp(28px, 4vw, 46px) clamp(24px, 4vw, 52px)',
      display: 'flex', flexDirection: 'column', gap: compact ? 14 : 22,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 16, borderBottom: '3px solid var(--ink)', paddingBottom: 12 }}>
        <span className="mono" style={{ fontSize: 13, letterSpacing: '0.1em', color: 'var(--paper-slate)' }}>CHARGEWORTHY</span>
        <span className="mono" style={{ fontSize: 13, color: 'var(--paper-muted)' }}>CW-2026-0412</span>
      </div>
      <div style={{ fontSize: compact ? 20 : 25 }}>NH-<span className="mono">66</span>, Kasaragod</div>
      <div style={{ borderTop: '2px solid var(--ink)', paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ fontSize: compact ? 26 : 34, letterSpacing: '0.02em', color: 'var(--verdict-negative)' }}>DON&rsquo;T BUILD</div>
        <p style={{ fontSize: 16, lineHeight: 1.55 }}>
          Even in the optimistic case this site runs below the point where it covers its costs.
        </p>
      </div>
      {!compact && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 32, borderTop: '1px solid var(--rule)', paddingTop: 18 }}>
          {[['Capital required', '₹34L'], ['This site', '2.1%'], ['Fixed deposit', '7.1%'], ['Payback', 'None']].map(([l, v]) => (
            <div key={l} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <span style={{ fontSize: 15, color: 'var(--paper-muted)' }}>{l}</span>
              <span className="mono" style={{ fontSize: 28, fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const CALLOUTS = [
  ['01', 'The verdict, first', 'One word and one sentence, before any statistics.'],
  ['02', 'Set against a fixed deposit', 'The comparison you were going to make anyway, made for you.'],
  ['03', 'The assumptions ledger', 'Every input we used. The unverified ones are shown, not buried.'],
];

function Report() {
  const [ref, progress] = useScrollProgress();
  return (
    <section id="report" ref={ref} className="section">
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 380px), 1fr))',
        gap: 'clamp(36px, 5vw, 72px)', alignItems: 'start',
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 452 }}>
          <Eyebrow>The report</Eyebrow>
          <h2 style={{ fontSize: 'clamp(26px, 3.4vw, 34px)' }}>A document your bank will accept.</h2>
          <p className="muted">
            Detailed enough to sanction a loan against, and written to be read in plain language first.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', paddingTop: 18 }}>
            {CALLOUTS.map(([n, title, body], i) => {
              // Scroll-linked: the one place it is justified, because the
              // movement mirrors reading down a document.
              const shown = progress > 0.22 + i * 0.16;
              return (
                <div
                  key={n}
                  style={{
                    display: 'flex', gap: 18, padding: '20px 0', borderTop: '1px solid var(--line)',
                    borderBottom: i === CALLOUTS.length - 1 ? '1px solid var(--line)' : 'none',
                    opacity: shown ? 1 : 0.25,
                    transform: shown ? 'none' : 'translateY(10px)',
                    transition: 'opacity 500ms var(--ease), transform 500ms var(--ease)',
                  }}
                >
                  <span className="mono" style={{ fontSize: 14, color: 'var(--slate)', flexShrink: 0, paddingTop: 2 }}>{n}</span>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <h3 style={{ fontSize: 17 }}>{title}</h3>
                    <p className="muted">{body}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div style={{
          transform: `translateY(${(1 - Math.min(progress * 1.6, 1)) * 24}px)`,
          transition: 'transform 120ms linear',
        }}>
          <ReportPaper />
        </div>
      </div>
    </section>
  );
}

function Cards() {
  const ref = useReveal(50);
  const [pctRef, pct] = useCountUp(38);
  return (
    <section ref={ref} className="section">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(32px, 4vw, 48px)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 660 }}>
          <div data-reveal="0"><Eyebrow>Why trust the answer</Eyebrow></div>
          <h2 data-reveal="1" style={{ fontSize: 'clamp(26px, 3.4vw, 34px)' }}>We have no stake in you building.</h2>
          <p data-reveal="2" className="muted" style={{ fontSize: 18, maxWidth: 620 }}>
            Chargeworthy is not a charge point operator. We own no stations, take no margin on
            hardware, and charge the same assessment fee whether the answer is yes or no.
          </p>
        </div>

        <div className="cards">
          <div className="card span-8" data-reveal="3" style={{ padding: 'clamp(28px, 4vw, 48px) clamp(24px, 4vw, 52px)', display: 'flex', flexDirection: 'column', gap: 24, justifyContent: 'center' }}>
            <h3 style={{ fontSize: 26 }}>We tell people not to build.</h3>
            <div ref={pctRef} className="mono" style={{ fontSize: 'clamp(56px, 8vw, 96px)', lineHeight: 1, fontWeight: 500, letterSpacing: '-0.03em', color: 'var(--accent)' }}>
              {pct}%
            </div>
            <p className="muted" style={{ fontSize: 18, maxWidth: 540 }}>
              Of <span className="mono">340</span> sites assessed in <span className="mono">2025</span>, we advised{' '}
              <span className="mono">129</span> owners to walk away. We were paid the same either way.
            </p>
          </div>

          <div className="card span-4" data-reveal="4" style={{ padding: 'clamp(24px, 3vw, 40px)', display: 'flex', flexDirection: 'column', gap: 18, justifyContent: 'center' }}>
            <Eyebrow>Prediction accuracy</Eyebrow>
            <div className="mono" style={{ fontSize: 'clamp(38px, 5vw, 56px)', lineHeight: 1, fontWeight: 500 }}>[XX%]</div>
            <p className="muted">
              Of the sites we cleared that went on to be built, this share landed inside our
              projected utilisation band after twelve months.
            </p>
          </div>

          <LogoCard reveal="5" title="Matched to the right operator, not our own." names={['GOEC', 'CHARGEMOD', 'CHARGEZONE']} />
          <LogoCard reveal="6" title="Independent across hardware." names={['LUBI', 'ABB', 'QUENCH']}
                    note="No stake in any charger brand, no margin on hardware." />

          <div className="card span-4" data-reveal="7" style={{ padding: 'clamp(24px, 3vw, 40px)', display: 'flex', flexDirection: 'column', gap: 18, justifyContent: 'center' }}>
            <div className="mono" style={{ fontSize: 'clamp(38px, 5vw, 56px)', lineHeight: 1, fontWeight: 500 }}>1,000+</div>
            <p className="muted">
              Station owners in our network across India, and the reason our operator comparisons
              are grounded in what actually happens after commissioning.
            </p>
          </div>

          <div className="card span-12" data-reveal="8" style={{ padding: 'clamp(28px, 4vw, 48px) clamp(24px, 4vw, 52px)', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 320px), 1fr))', gap: 'clamp(28px, 4vw, 56px)', alignItems: 'center' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              <Eyebrow>See a full assessment</Eyebrow>
              <h3 style={{ fontSize: 24 }}>Every site gets the same document, whatever the verdict.</h3>
              <p className="muted">Read a real one end to end before you order your own.</p>
            </div>
            <div style={{ maxHeight: 236, overflow: 'hidden' }}><ReportPaper compact /></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function LogoCard({ title, names, note, reveal }) {
  return (
    <div className="card span-4" data-reveal={reveal} style={{ padding: 'clamp(24px, 3vw, 40px)', display: 'flex', flexDirection: 'column', gap: 22 }}>
      <h3 style={{ fontSize: 20, lineHeight: 1.35 }}>{title}</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 13 }}>
        {names.map((n) => (
          <span key={n} className="mono muted" style={{ fontSize: 18, letterSpacing: '0.06em' }}>{n}</span>
        ))}
      </div>
      {note && <p className="muted">{note}</p>}
    </div>
  );
}

function Close() {
  const ref = useReveal(60);
  return (
    <section ref={ref}>
      <div className="section" style={{ display: 'flex', flexDirection: 'column', gap: 28, alignItems: 'flex-start' }}>
        <h2 data-reveal="0" style={{ fontSize: 'clamp(28px, 4vw, 42px)', maxWidth: 660 }}>
          Start with the location. We will tell you the rest.
        </h2>
        <div data-reveal="1" style={{ width: '100%' }}><LocationCta id="close-location" /></div>
      </div>

      <footer style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap',
        gap: 40, padding: '40px var(--pad-x) 48px', borderTop: '1px solid var(--line)',
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 620 }}>
          <span className="mono" style={{ fontWeight: 500, fontSize: 15, letterSpacing: '0.09em', textTransform: 'uppercase' }}>
            Chargeworthy
          </span>
          <p className="muted" style={{ fontSize: 16 }}>
            Chargeworthy is not a charge point operator and holds no stake in any station or
            charger brand. We earn a fee when a site proceeds to installation with a partner
            operator. Assessment fees are not contingent on a positive verdict.
          </p>
        </div>
        <nav style={{ display: 'flex', gap: 32 }}>
          <a href="#report" style={{ display: 'inline-flex', alignItems: 'center', minHeight: 44, fontSize: 16 }}>Sample report</a>
          <a href="mailto:hello@chargeworthy.in" style={{ display: 'inline-flex', alignItems: 'center', minHeight: 44, fontSize: 16 }}>Contact</a>
        </nav>
      </footer>
    </section>
  );
}

export default function Landing() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <HowItWorks />
        <WhatWeCheck />
        <Cards />
        <Report />
        <Close />
      </main>
    </>
  );
}
