import { useCallback, useEffect, useRef, useState } from 'react';
import { BackgroundMap, LocateMap } from '../components/Maps';

// One question per screen. No dropdowns anywhere in this file — that is the
// point of the flow, not an implementation detail.
const STEPS = [
  { id: 'locate',     label: '01 / 04', progress: 25 },
  { id: 'transformer',label: '02 / 04', progress: 50 },
  { id: 'distance',   label: '02 / 04', progress: 58 },
  { id: 'capacity',   label: '02 / 04', progress: 66 },
  { id: 'land',       label: '03 / 04', progress: 75 },
  { id: 'intent',     label: '04 / 04', progress: 100 },
  { id: 'working',    label: 'WORKING', progress: 100 },
  { id: 'result',     label: 'RESULT',  progress: 100 },
];

const STORE = 'cw.assessment';

function loadState() {
  try {
    return JSON.parse(sessionStorage.getItem(STORE) ?? '{}');
  } catch {
    return {};
  }
}
function saveState(next) {
  try {
    sessionStorage.setItem(STORE, JSON.stringify(next));
  } catch { /* private browsing — the flow still works, it just won't survive a refresh */ }
}

function stepFromHash() {
  const id = window.location.hash.split('/')[2];
  return STEPS.some((s) => s.id === id) ? id : 'locate';
}

const CHEVRON = (
  <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor"
       strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M12.5 4.5 L6.5 10 L12.5 15.5" />
  </svg>
);

// --- Chrome -------------------------------------------------------------

function Chrome({ step, onBack, backLabel, children, bare = false }) {
  const meta = STEPS.find((s) => s.id === step);
  return (
    <div style={{ position: 'relative', minHeight: '100dvh', display: 'flex', flexDirection: 'column' }}>
      <header style={{
        position: 'relative', zIndex: 2,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 24,
        padding: '20px var(--pad-x)', background: 'var(--ground)',
      }}>
        <a href="#/" className="mono" style={{ display: 'inline-flex', alignItems: 'center', minHeight: 44, fontWeight: 500, fontSize: 16, letterSpacing: '0.09em', textTransform: 'uppercase', color: 'var(--text)' }}>
          Chargeworthy
        </a>
        <span className="mono muted" style={{ fontSize: 14, letterSpacing: '0.08em' }}>{meta.label}</span>
      </header>

      {/* Quiet hairline. Never a percentage in text. */}
      <div style={{ position: 'relative', zIndex: 2, height: 2, background: 'var(--line)' }}>
        <div
          style={{
            height: 2, width: `${meta.progress}%`, background: 'var(--slate)',
            transition: 'width 420ms var(--ease)',
          }}
        />
      </div>

      {onBack && (
        <div style={{ position: 'relative', zIndex: 2, padding: '14px var(--pad-x) 0' }}>
          <button
            type="button"
            onClick={onBack}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 10, minHeight: 56,
              padding: '0 4px', background: 'none', border: 'none', color: 'var(--muted)', fontSize: 17,
            }}
          >
            {CHEVRON}{backLabel ?? 'Back'}
          </button>
        </div>
      )}

      <div style={{
        position: 'relative', zIndex: 2, flexGrow: 1,
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        padding: bare ? 0 : 'clamp(24px, 5vw, 56px) var(--pad-x) clamp(48px, 7vw, 72px)',
      }}>
        {children}
      </div>

      {!bare && <MapAttribution />}
    </div>
  );
}

/** Mapbox requires attribution. The dimmed background map cannot carry the
 *  built-in control legibly, so it is rendered here as real, clickable text. */
function MapAttribution() {
  return (
    <div style={{
      position: 'relative', zIndex: 2,
      padding: '0 var(--pad-x) 18px', fontSize: 13, color: 'var(--muted)',
      display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 6,
    }}>
      <a href="https://www.mapbox.com/about/maps/" target="_blank" rel="noreferrer noopener"
         style={{ display: 'inline-flex', alignItems: 'center', minHeight: 44, fontSize: 13 }}>
        &copy; Mapbox
      </a>
      <span aria-hidden="true"> &middot; </span>
      <a href="https://www.openstreetmap.org/about/" target="_blank" rel="noreferrer noopener"
         style={{ display: 'inline-flex', alignItems: 'center', minHeight: 44, fontSize: 13 }}>
        &copy; OpenStreetMap
      </a>
    </div>
  );
}

function Question({ children }) {
  return (
    <h1 style={{ fontSize: 'clamp(30px, 4.6vw, 46px)', fontWeight: 500, maxWidth: 820 }}>{children}</h1>
  );
}

function Answers({ children, cols = 2 }) {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: `repeat(auto-fit, minmax(min(100%, ${cols === 3 ? 260 : 320}px), 1fr))`,
      gap: 20,
    }}>
      {children}
    </div>
  );
}

function Answer({ title, sub, onClick }) {
  return (
    <button type="button" className="answer" onClick={onClick}>
      <span style={{ fontSize: 22, fontWeight: 500, letterSpacing: '-0.015em', lineHeight: 1.3 }}>{title}</span>
      <span className="muted">{sub}</span>
    </button>
  );
}

function Slider({ label, value, min, max, step, unit, onChange, id }) {
  return (
    <div className="card" style={{ padding: 'clamp(22px, 3vw, 32px) clamp(20px, 3vw, 36px)', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 20, flexWrap: 'wrap' }}>
        <label htmlFor={id} style={{ fontSize: 20, fontWeight: 500 }}>{label}</label>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <span className="mono" style={{ fontSize: 'clamp(30px, 5vw, 40px)', fontWeight: 500, letterSpacing: '-0.02em' }}>{value}</span>
          <span className="mono muted" style={{ fontSize: 18 }}>{unit}</span>
        </div>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-valuetext={`${value} ${unit}`}
      />
    </div>
  );
}

function Footer({ onSkip, onNext, skipLabel = 'I don’t know this one — skip it' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
      <button type="button" onClick={onSkip}
              style={{ display: 'inline-flex', alignItems: 'center', minHeight: 56, background: 'none', border: 'none', color: 'var(--muted)', fontSize: 17 }}>
        {skipLabel}
      </button>
      <button type="button" className="btn" onClick={onNext}>Continue</button>
    </div>
  );
}

// --- Working ------------------------------------------------------------

const CHECKS = [
  'Kerala electricity regulator tariff order, FY 2025-26',
  'EV registrations, Kasaragod district (VAHAN)',
  'Competitor scan, 10 km radius',
  'Power cut record, last 24 months (KSEB)',
  'Daily traffic count, NH-66 northbound',
  'Transformer proximity and spare capacity',
  'Amenities, and how long drivers stop here',
];

const TICK = (
  <svg width="17" height="17" viewBox="0 0 20 20" fill="none" stroke="var(--positive)" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M4 10.5 L8.2 14.5 L16 5.5" />
  </svg>
);
const RING = (color) => (
  <svg width="17" height="17" viewBox="0 0 20 20" fill="none" stroke={color} strokeWidth="1.7" aria-hidden="true">
    <circle cx="10" cy="10" r="4.4" />
  </svg>
);

/**
 * Shows real progress through the assessment.
 *
 * `runAssessment` must be replaced with the call to your own backend. It
 * receives a reporter and should call it as each source genuinely resolves.
 * Do NOT pad this with a timer: if the real work takes two seconds, show two
 * seconds. A progress bar that waits for effect is the one element on this
 * site that would undo everything else it argues.
 */
async function runAssessmentStub(report) {
  for (let i = 0; i < CHECKS.length; i += 1) {
    // eslint-disable-next-line no-await-in-loop
    await new Promise((r) => { setTimeout(r, 900 + Math.random() * 900); });
    report(i + 1);
  }
}

function Working({ onDone, runAssessment = runAssessmentStub }) {
  const [done, setDone] = useState(0);
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    let alive = true;
    runAssessment((n) => { if (alive) setDone(n); })
      .then(() => { if (alive) onDone(); })
      .catch((err) => { console.error('[Chargeworthy] assessment failed', err); });
    return () => { alive = false; };
  }, [onDone, runAssessment]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(32px, 5vw, 44px)', maxWidth: 880 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <h1 style={{ fontSize: 'clamp(28px, 4vw, 40px)', fontWeight: 500 }}>
          Checking <span className="mono">34</span> factors against this location.
        </h1>
        <p className="muted" style={{ maxWidth: 640 }}>
          We are checking the live records now. This takes about fifteen seconds.
        </p>
      </div>

      <ol role="status" aria-live="polite" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
        {CHECKS.map((c, i) => {
          const state = i < done ? 'done' : i === done ? 'active' : 'pending';
          return (
            <li key={c} style={{
              display: 'flex', alignItems: 'center', gap: 18,
              padding: '17px 0', borderBottom: '1px solid var(--line)',
              transition: 'color 300ms var(--ease)',
              color: state === 'pending' ? 'var(--muted)' : 'var(--text)',
            }}>
              <span style={{ display: 'flex', flexShrink: 0 }}>
                {state === 'done' ? TICK : RING(state === 'active' ? 'var(--slate)' : 'var(--line)')}
              </span>
              <span className="mono" style={{ fontSize: 17 }}>{c}</span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

// --- Result -------------------------------------------------------------

function Result({ onRestart }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(32px, 5vw, 44px)', maxWidth: 900 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div className="mono muted" style={{ fontSize: 13, letterSpacing: '0.16em', textTransform: 'uppercase' }}>The verdict</div>
        <h1 style={{ fontSize: 'clamp(40px, 7vw, 68px)', fontWeight: 600, letterSpacing: '-0.03em', color: 'var(--negative)' }}>
          DON&rsquo;T BUILD
        </h1>
        <p style={{ fontSize: 'clamp(18px, 2.4vw, 21px)', lineHeight: 1.55, maxWidth: 720 }}>
          Even in the optimistic case this site runs below the point where it covers its costs.
        </p>
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 200px), 1fr))', gap: 28,
        borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)', padding: '32px 0',
      }}>
        {[['This site, effective return', '2.1%'], ['A fixed deposit, same money', '7.1%'], ['Payback', 'None']].map(([l, v]) => (
          <div key={l} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <span className="muted">{l}</span>
            <span className="mono" style={{ fontSize: 'clamp(34px, 5vw, 46px)', fontWeight: 500, letterSpacing: '-0.025em' }}>{v}</span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 24 }}>
        <p className="muted" style={{ maxWidth: 460 }}>
          The full report shows all 34 factors, including the ones that argued in this site&rsquo;s favour.
        </p>
        <button type="button" className="btn" onClick={onRestart}>Send me the full report</button>
      </div>
    </div>
  );
}

// --- Flow ---------------------------------------------------------------

export default function Flow() {
  const [step, setStep] = useState(stepFromHash);
  const [data, setData] = useState(loadState);

  useEffect(() => {
    const onHash = () => setStep(stepFromHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  useEffect(() => { saveState(data); }, [data]);

  // Pushing a hash means the browser back button works for free.
  const go = useCallback((id) => { window.location.hash = `#/assess/${id}`; }, []);
  const back = useCallback(() => window.history.back(), []);
  const set = useCallback((patch) => setData((d) => ({ ...d, ...patch })), []);

  const center = data.site?.coordinates;

  // Step 1 owns the whole viewport: the map is the interface, not a backdrop.
  if (step === 'locate') {
    return (
      <Chrome step="locate" bare>
        <div style={{ position: 'relative', flexGrow: 1, minHeight: '60vh' }}>
          <LocateMap onConfirm={(site) => { set({ site }); go('transformer'); }} />
        </div>
      </Chrome>
    );
  }

  const body = (() => {
    switch (step) {
      case 'transformer':
        return (
          <Screen question="Is there a transformer near this site?">
            <Answers>
              <Answer title="Yes, I know the details"
                      sub="Two quick questions about it, one at a time."
                      onClick={() => go('distance')} />
              <Answer title="Not sure — skip this"
                      sub="Most owners do not know. We will estimate it from the grid records."
                      onClick={() => { set({ transformer: 'unknown' }); go('land'); }} />
            </Answers>
            <p className="muted" style={{ maxWidth: 720 }}>
              Skipping widens the range on the estimate. It does not stop the assessment, and the
              report will mark the figure unverified.
            </p>
          </Screen>
        );

      case 'distance':
        return (
          <Screen question="How far is the transformer from the site?">
            <Slider id="tx-distance" label="Distance from the site" unit="m"
                    min={0} max={1000} step={10}
                    value={data.txDistance ?? 120}
                    onChange={(v) => set({ txDistance: v })} />
            <Footer onSkip={() => { set({ txDistance: null }); go('land'); }} onNext={() => go('capacity')} />
          </Screen>
        );

      case 'capacity':
        return (
          <Screen question="How big is it?">
            <Slider id="tx-capacity" label="Transformer capacity" unit="kVA"
                    min={25} max={1000} step={25}
                    value={data.txCapacity ?? 250}
                    onChange={(v) => set({ txCapacity: v })} />
            <Footer onSkip={() => { set({ txCapacity: null }); go('land'); }} onNext={() => go('land')} />
          </Screen>
        );

      case 'land':
        return (
          <Screen question="How much space do you have?">
            <Answers cols={3}>
              <Answer title="A couple of car parks" sub="Room for two or three vehicles to charge at once."
                      onClick={() => { set({ land: 'small' }); go('intent'); }} />
              <Answer title="A corner of a plot or yard" sub="Room for four to eight, with space to turn in and out."
                      onClick={() => { set({ land: 'medium' }); go('intent'); }} />
              <Answer title="An open site" sub="Room for a full station, a canopy and queueing."
                      onClick={() => { set({ land: 'large' }); go('intent'); }} />
            </Answers>
            <p className="muted" style={{ maxWidth: 720 }}>
              A rough answer is enough. We measure the plot properly during the site survey.
            </p>
          </Screen>
        );

      case 'intent':
        return (
          <Screen question="What do you want this site to do?">
            <Answers cols={3}>
              <Answer title="Earn from land I already own" sub="You have the space and want it to produce an income."
                      onClick={() => { set({ intent: 'income' }); go('working'); }} />
              <Answer title="Serve my own fleet" sub="Vehicles you operate, charging on a predictable schedule."
                      onClick={() => { set({ intent: 'fleet' }); go('working'); }} />
              <Answer title="Serve visitors to my property" sub="A mall, hotel, office or apartment block where people already stop."
                      onClick={() => { set({ intent: 'visitors' }); go('working'); }} />
            </Answers>
            <p className="muted" style={{ maxWidth: 720 }}>
              This changes which operators suit you, and how busy we expect the site to be.
            </p>
          </Screen>
        );

      case 'working':
        return <Working onDone={() => go('result')} />;

      case 'result':
        return <Result onRestart={() => go('locate')} />;

      default:
        return null;
    }
  })();

  const backLabel = {
    distance: 'Back to the transformer question',
    capacity: 'Back to the distance',
    working: 'Change an answer',
    result: 'Back to my answers',
  }[step];

  return (
    <Chrome step={step} onBack={back} backLabel={backLabel}>
      {/* The map stays continuous behind every step, so location context is never lost. */}
      <BackgroundMap center={center} />
      {body}
    </Chrome>
  );
}

function Screen({ question, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(32px, 5vw, 44px)', maxWidth: 940 }}>
      <Question>{question}</Question>
      {children}
    </div>
  );
}
