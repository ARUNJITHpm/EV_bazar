import { useEffect, useState } from 'react';
import Landing from './pages/Landing';
import Flow from './pages/Flow';

/** Hash routing: no dependency, and the browser back button works everywhere. */
function useRoute() {
  const [hash, setHash] = useState(() => window.location.hash);
  useEffect(() => {
    const on = () => setHash(window.location.hash);
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return hash;
}

export default function App() {
  const hash = useRoute();
  const inFlow = hash.startsWith('#/assess');

  useEffect(() => {
    // Entering the flow should start at the top, not mid-scroll.
    if (inFlow) window.scrollTo(0, 0);
  }, [inFlow]);

  return inFlow ? <Flow /> : <Landing />;
}
