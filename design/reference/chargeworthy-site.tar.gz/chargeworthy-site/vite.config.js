import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        // Mapbox is the heaviest dependency. Splitting it lets the rest of the
        // page paint before it arrives.
        manualChunks: { mapbox: ['mapbox-gl'] },
      },
    },
  },
});
