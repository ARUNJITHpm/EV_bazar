#!/usr/bin/env node
// Populate the report template from an assessment JSON file.
//
//   node build-report.mjs report-data.json out.html
//
// Replaces the contents of the #report-data script tag and nothing else, so
// the template's layout and print rules stay untouched between releases.

import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const [, , dataPath = join(here, 'report-data.json'), outPath = join(here, 'report.html')] = process.argv;

const template = readFileSync(join(here, 'chargeworthy-report.html'), 'utf8');
const data = JSON.parse(readFileSync(dataPath, 'utf8'));

// `</script>` inside a JSON string would close the tag early. This is the one
// escaping hazard in a JSON island, so handle it explicitly.
const json = JSON.stringify(data, null, 2).replace(/<\/script/gi, '<\\/script');

const START = '<script type="application/json" id="report-data">';
const END = '</script>';
const start = template.indexOf(START);
if (start === -1) throw new Error('data slot not found in template');
const end = template.indexOf(END, start + START.length);

const out = template.slice(0, start + START.length) + '\n' + json + '\n' + template.slice(end);
writeFileSync(outPath, out);

const site = data?.meta?.site ?? '(no site)';
console.log(`wrote ${outPath} — ${site} (${(out.length / 1024).toFixed(1)} KB)`);
