# Chargeworthy — site assessment report

One self-contained HTML file. All content comes from a single JSON block, so a
real assessment populates it without touching layout or print rules.

```
chargeworthy-report.html          the template
report-data.json                  an example assessment (placeholder data)
build-report.mjs                  fills the template from a JSON file
report.html                       the example, rendered
chargeworthy-report-example.pdf   the example, printed to A4
```

## Generate one

```bash
node build-report.mjs my-assessment.json out.html
```

The script replaces the contents of the `#report-data` script tag and nothing
else. Any language can do the same — it is a plain string substitution into one
tag. `build-report.mjs` escapes `</script` inside strings, which is the only
escaping hazard in a JSON island; do the same if you reimplement it.

## Structure

Eleven sections, in this order and for this reason:

| | |
|---|---|
| 01 Verdict | One word and one sentence, before any statistics |
| 02 What this means for your money | Return set beside a fixed deposit — the comparison the reader was going to make anyway |
| 03 How this site was judged | Thresholds stated **before** the data, so the standard visibly was not fitted to the conclusion |
| 04 Site factors | All 34, grouped, with the favourable ones at equal weight |
| 05 Financials | |
| 06 Competitors | |
| 07 What would change this verdict | Checkable conditions — this is why a reader trusts a no |
| 08 Statistical basis | The confidence band, demoted here for the accountant |
| 09 Assumptions ledger | Unverified inputs shown, not buried |
| 10 Provenance | Starts a new page in print |
| 11 Disclosure and independence | Including the proportion of sites rejected |

## Verified, not assumed

Rendered headless and printed to A4:

- **9 pages**, no orphaned table headers, no section split mid-block
- Provenance and disclosure close the document on their own page
- **34 factor rows** — matches the "34 factors" claim exactly
- **One chart** in the whole document, the confidence band
- Zero horizontal overflow
- Greyscale print checked: the verdict and every direction marker stay legible

## Colour carries no meaning

Direction markers are a **sign plus a word** — `+ FAVOURS`, `− AGAINST`,
`· NEUTRAL`. Printed black and white, a red dot and a green dot become two
identical grey dots and section 04 loses its entire function. Colour here is
reinforcement only. Same for the verdict: the words are the meaning.

## Verdict codes

`verdict.code` sets the colour; `verdict.label` is the text.

| code | renders |
|---|---|
| `dont-build` | dark red |
| `build` | dark green |
| `conditional` | copper |

## Known limits

- **Page numbers.** `@page` margin boxes are in the stylesheet but Chrome does
  not render them. Chrome's own print dialog adds page numbers, or use a paged
  engine (WeasyPrint, Prince) if you need them typeset.
- **Fonts.** Source Serif 4 and IBM Plex Mono load from Google Fonts as
  progressive enhancement. The document is fully legible in the fallbacks
  (Georgia, Courier), which is what matters when it is printed or emailed. If
  you need exact typography offline, embed the faces as data URIs.
- **JavaScript renders the document.** Fine when you generate server-side and
  ship the output; if you need a no-JS artefact, print to PDF once and send that.

## Before a real report goes out

Everything in `report-data.json` is placeholder. In particular:

- `meta.assessor` and every competitor operator name are marked PLACEHOLDER
- `statistical.model` needs your real model name and version
- `disclosure.rejectionRate` must match your actual figures

Sections 03, 07 and 11 make claims your operation has to be able to back —
fixed thresholds applied to every site, a real rejection rate, fees genuinely
not contingent on a positive verdict. Those are what earn the trust, and they
are also what would cost you badly if a bank checked and found them decorative.
